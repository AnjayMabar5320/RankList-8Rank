<?php

namespace AnjayMabar;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as C;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\utils\Config;
use jojoe77777\FormAPI;
use jojoe77777\FormAPI\SimpleForm;

class Main extends PluginBase implements Listener{

    public function onEnable(){
        $this->getLogger()->info(C::GREEN . "[Enabled] Plugin Petshop By AnjayMabar");
    }

    public function onLoad(){
        $this->getLogger()->info(C::YELLOW . "[Loading] Plugin Sedang Loading");
    }

    public function onDisable(){
        $this->getLogger()->info(C::RED . "[Disable] Plugin Terdapat Error / Butuh FormAPI");
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
        switch($cmd->getName()){                    
            case "petshop":
                if($sender instanceof Player){
                    $this->petshop($sender);
                }else{
                    $sender->sendMessage("§cGunakan Command Dalam Game!");
                } 
                break;
        }
        return true;
    }

    public function petshop($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
                break;
                case 1:
                    $this->petbiasa($sender);
                break;
                case 2:
                    $this->petpremium($sender);
                break;
                case 3:
                    $this->petlangka($sender);
                break;
                case 4:
                    $this->tips($sender);
                break;
				case 5:
                    $this->cpt($sender);
                break;

                }
            });
            $form->setTitle($this->getConfig()->get("Title"));
            $form->setContent($this->getConfig()->get("Content"));
            $form->addButton($this->getConfig()->get("Keluar",  1, "http://1.bp.blogspot.com/-p_yW3DL-c8k/UutcZx_GQuI/AAAAAAAAAA4/1iENqHd3dQQ/s1600/cross_icon.jpg"));
            $form->addButton("Pet Biasa\nTap to Open", 1, "https://www.blogteraktual.com/wp-content/uploads/2018/06/gambar-wallpaper-kartun-binatang-update-gambar-kartun-gajah-lucu-terkini-of-gambar-wallpaper-kartun-binatang.png");
            $form->addButton("Pet Premium\nTap to Open", 1, "https://www.blogteraktual.com/wp-content/uploads/2018/06/gambar-wallpaper-kartun-binatang-update-gambar-kartun-gajah-lucu-terkini-of-gambar-wallpaper-kartun-binatang.png");
            $form->addButton("Pet Langka\nTap to Open", 1, "https://www.blogteraktual.com/wp-content/uploads/2018/06/gambar-wallpaper-kartun-binatang-update-gambar-kartun-gajah-lucu-terkini-of-gambar-wallpaper-kartun-binatang.png");
            $form->addButton("Tips Pets\nTap to Open", 1, "https://www.chronosly.com/wp-content/uploads/2015/01/chronosly-tips-logo.png");
            $form->addButton("Commands Pets\nTap to Open", 1, "https://www.chronosly.com/wp-content/uploads/2015/01/chronosly-tips-logo.png");
            $form->sendToPlayer($sender);
            return $form;
    }

     public function petbiasa($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
            $command = "petshop" ;
            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;

                }
            });
            $form->setTitle("§bPet Biasa");
            $form->setContent($this->getConfig()->get("Info-PetBiasa"));
            $form->addButton($this->getConfig()->get("Kembali"));
            $form->sendToPlayer($sender);
            return $form;
    }

    public function petpremium($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
            $command = "petshop" ;
            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;

                }
            });
            $form->setTitle("§bPet Premium");
            $form->setContent($this->getConfig()->get("Info-PetPremium"));
            $form->addButton($this->getConfig()->get("Kembali"));
            $form->sendToPlayer($sender);
            return $form;
    }

    public function petlangka($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
            $command = "petshop" ;
            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;

                }
            });
            $form->setTitle("§bPet Langka");
            $form->setContent($this->getConfig()->get("Info-PetLangka"));
            $form->addButton($this->getConfig()->get("Kembali"));
            $form->sendToPlayer($sender);
            return $form;
    }

    public function tips($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
            $command = "petshop" ;
            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;

                }
            });
            $form->setTitle("§bTips Pets");
            $form->setContent($this->getConfig()->get("Info-Tips"));
            $form->addButton($this->getConfig()->get("Kembali"));
            $form->sendToPlayer($sender);
            return $form;
    }
	
	public function cpt($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
            $command = "petshop" ;
            $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;

                }
            });
            $form->setTitle("§bCommands Pets");
            $form->setContent($this->getConfig()->get("Info-Command"));
            $form->addButton($this->getConfig()->get("Kembali"));
            $form->sendToPlayer($sender);
            return $form;
    }

    
}