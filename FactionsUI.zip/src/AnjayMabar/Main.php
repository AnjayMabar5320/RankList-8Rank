<?php

/**
*    ^
*     ╔══════════╗  ╔══════════╗
*     ║          ║  ║  ╔═══════╝
*     ║  ╔════╗  ║  ║  ║           
*     ║  ║    ║  ║  ║  ║          AnjayMabar5320
*     ║  ╚════╝  ║  ║  ╚═══════╗  Discord: PedhotSpijikun#0275
*     ║  ╔════╗  ║  ║  ╔════╗  ║  Github: PedhotNoob(MinionID)
*     ║  ║    ║  ║  ║  ║    ║  ║
*     ║  ║    ║  ║  ║  ╚════╝  ║ 
*     ╚══╝    ╚══╝  ╚══════════╝
*/

namespace AnjayMabar;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\command\ConsoleCommandSender;

use jojoe77777\FormAPI;
use jojoe77777\FormAPI\SimpleForm;

class Main extends PluginBase implements Listener {
	
	public function onEnable(){
        $this->getLogger()->info(C::GREEN . "[Enabled] Plugin FactionsUI By AnjayMabar");
    }

    public function onLoad(){
        $this->getLogger()->info(C::YELLOW . "[Loading] Plugin Sedang Loading");
    }

    public function onDisable(){
        $this->getLogger()->info(C::RED . "[Disable] Plugin Terdapat Error / Butuh FormAPI");
    }
	
	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
        switch($cmd->getName()){                    
            case "fui":
                if($sender instanceof Player){
                    $this->fui($sender);
                }else{
                    $sender->sendMessage("§cGunakan Command Dalam Game!");
                } 
                break;
        }
        return true;
    }
	
	public function fui($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->create($sender);
                break;
                case 1:
                    $this->del($sender);
                break;
                case 2:
                    $this->invite($sender);
                break;
                case 3:
                    $this->kick($sender);
                break;
                case 4:
                    $command = "f sethome" ;
                    $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;
			    case 5:
                    $command = "f home" ;
                    $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;
                case 6:
                    $command = "f topfactions" ;
                    $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;
                case 7:
                    $command = "f topmoney" ;
                    $this->getServer()->getCommandMap()->dispatch($sender, $command);
                break;
				case 8:
                    $this->say($sender);
                break;
			}
			
		});
		$form->setTitle("§l§aFactionsUI");
		$form->setContent("§l§e•Pilih•");
		$form->addButton("§l§6•Buat Tim•");
		$form->addButton("§l§c•Hapus Tim•");
		$form->addButton("§l§d•Undang•");
		$form->addButton("§l§b•Tendang•");
		$form->addButton("§l§1•Set Home•");
		$form->addButton("§l§5•Home•");
		$form->addButton("§l§f•Top Power•");
		$form->addButton("§l§9•Top Balance•");
		$form->addButton("§l§a•Say•");
	}
	
	public function create(Player $sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $sender, int $data = null){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "f create $data[0]");
		});
		
		$f->setTitle($this->setName() . "§l§a•FactionsUI•");
		$f->addInput("Nama Faction", "Ngeteh");
		$f->sendToPlayer($sender);
	}
	
	public function del($sender){ 
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
                    $command = "f del" ;
                    $this->getServer()->getCommandMap()->dispatch($sender, $command);
					$sender->sendMessage("§cBerhasil Menghapus Faction");
                    $sender->addTitle("§cFaction Berhasil DiHapus");
                break;
				case 1:
				    $sender->sendMessage("§eTidak Jadi Menghapus Faction");
                break;

            }
        });
        $form->setTitle("§l§a•FactionsUI•");
        $form->setContent("Pilih Ya / Tidak");
        $form->addButton("Ya");
        $form->addButton("Tidak");
	    $form->sendToPlayer($sender);
        return $form;
    }
	
	public function invite(Player $sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $sender, int $data = null){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "f invite $data[0]");
		});
		
		$f->setTitle($this->setName() . "§l§a•FactionsUI•");
		$f->addInput("Nama Pemain", "AnjayMabar5320");
		$f->sendToPlayer($sender);
	}
	
	public function kick(Player $sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $sender, int $data = null){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "f kick $data[0]");
		});
		
		$f->setTitle($this->setName() . "§l§a•FactionsUI•");
		$f->addInput("Nama Pemain", "DandierSmile122");
		$f->sendToPlayer($sender);
	}
	
	public function say(Player $sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $sender, int $data = null){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "f say $data[0]");
		});
		
		$f->setTitle($this->setName() . "§l§a•FactionsUI•");
		$f->addInput("Isi Pesan", "Ngumpul Oyyyy");
		$f->sendToPlayer($sender);
	}
	
	
	
	
	
}
